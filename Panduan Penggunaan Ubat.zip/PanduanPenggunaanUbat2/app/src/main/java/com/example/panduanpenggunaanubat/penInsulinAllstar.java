package com.example.panduanpenggunaanubat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class penInsulinAllstar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pen_insulin_allstar);
    }
}
