package com.example.panduanpenggunaanubat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ubatPamEasyhaler extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubat_pam_easyhaler);
    }
}
